<template>
  <img style="z-index: -2" class="absolute top-0 h-full left-0 w-screen object-cover" src="@/assets/background.jpg" />
</template>
