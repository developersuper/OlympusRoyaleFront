<template>
  <router-link to="/collection" class="flex max-w-100 mx-auto w-full hover:scale-105 transition-transform duration-200 transform">
    <img class="h-full object-contain select-none" src="@/assets/viewcollection.png" />
  </router-link>
  <a
    rel="”nofollow”"
    target="_blank"
    class="flex border rounded-md max-w-50 w-full mx-auto justify-center bg-gray-100 bg-opacity-10 hover:bg-opacity-20 duration-200 transition-colors text-white border-gray-500 py-2 px-4"
    href="https://lootex.io/stores/olympus-royale"
    >Trade your NFT's</a
  >
</template>
